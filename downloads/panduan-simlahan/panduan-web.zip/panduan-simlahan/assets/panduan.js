
document.getElementById('book-search').addEventListener('submit',function(event){
 event.preventDefault();var query=document.getElementById('book-query').value.trim();
 if(!query)return;document.getElementById('book-query').blur();
 var found=typeof window.find==='function'&&window.find(query,false,false,true,false,false,false);
 document.getElementById('book-feedback').textContent=found?'Ditemukan. Klik lagi untuk berikutnya.':'Gunakan Ctrl+F / Cari di halaman untuk menelusuri.';
});
document.addEventListener('DOMContentLoaded',function(){
 var viewer=document.getElementById('capture-viewer'),body=document.getElementById('capture-viewer-body'),current=null,scale=1;
 function resize(){if(current){current.style.width=Math.round(current.naturalWidth*scale)+'px';}}
 function openImage(source){current=document.createElement('img');current.src=source.src;current.alt=source.alt;body.replaceChildren(current);document.getElementById('capture-viewer-title').textContent=source.alt;scale=1;viewer.showModal();current.decode().then(resize);}
 document.querySelectorAll('img.step-capture,img.section-capture').forEach(function(image){image.tabIndex=0;image.title='Klik untuk memperbesar gambar';image.addEventListener('click',function(){openImage(image)});image.addEventListener('keydown',function(event){if(event.key==='Enter'){openImage(image)}});});
 viewer.addEventListener('click',function(event){var action=event.target.getAttribute('data-image-action');if(action==='close'){viewer.close()}else if(action==='in'){scale=Math.min(3,scale*1.25);resize()}else if(action==='out'){scale=Math.max(.25,scale/1.25);resize()}else if(action==='fit'&&current){scale=Math.min(1,(body.clientWidth-32)/current.naturalWidth);resize()}});
 viewer.addEventListener('close',function(){body.replaceChildren();current=null});
});

document.addEventListener('DOMContentLoaded', function () {
  var toolbar = document.querySelector('.book-tools');
  function measureToolbar() {
    document.documentElement.style.setProperty('--book-tools-height', toolbar.getBoundingClientRect().height + 'px');
  }
  measureToolbar();
  if (typeof ResizeObserver === 'function') new ResizeObserver(measureToolbar).observe(toolbar);
  else window.addEventListener('resize', measureToolbar);
  var button = document.getElementById('book-print');
  var feedback = document.getElementById('book-feedback');
  button.addEventListener('click', async function () {
    if (button.disabled) return;
    button.disabled = true;
    var images = Array.from(document.querySelectorAll('img.step-capture,img.section-capture'));
    images.forEach(function (image) { image.loading = 'eager'; });
    try {
      for (var index = 0; index < images.length; index++) {
        if (!images[index].complete || !images[index].naturalWidth) await images[index].decode();
        if (index % 20 === 0) button.textContent = 'Menyiapkan ' + (index + 1) + '/' + images.length;
      }
      feedback.textContent = 'Semua gambar siap dicetak.';
      window.print();
    } catch (error) {
      feedback.textContent = 'Sebagian gambar belum termuat. Periksa koneksi, lalu coba cetak lagi.';
    } finally {
      button.disabled = false;
      button.textContent = 'Cetak';
    }
  });
  window.addEventListener('beforeprint', function () {
    document.querySelectorAll('img[loading="lazy"]').forEach(function (image) { image.loading = 'eager'; });
  });
});
